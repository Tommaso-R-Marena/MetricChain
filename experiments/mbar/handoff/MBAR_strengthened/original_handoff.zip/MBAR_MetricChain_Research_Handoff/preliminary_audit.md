# Preliminary independent audit — recovered Drive snapshot

Five source documents were retrieved as text exports from Google Drive; three code exports were copied byte-for-byte to their intended extensions. Original Drive files were not modified. The PDF is an unmodified manuscript compilation, not an endorsement of its contents.

## Execution
- Python original benchmark script completed with exit 0, seed 20261127, NumPy 2.3.5, SciPy 1.17.0. See benchmark_execution.log.
- pdflatex compiled manuscript (two passes); see latex_execution.log.
- Lean/Lake not installed on this runtime; no kernel verification performed; no pinned project supplied.
- All benchmarks synthetic. No actual pymbar API comparison in the original script; it reconstructs overlap from responsibilities. No real molecular benchmark. Theorem 2 applicability 150/150, 67/150, 2/150, 0/150; zero violations among applicable trials, no evidence in severe regime. 95% coverage shown is asymptotic, not coverage of new theorem.

## Mathematical and implementation issues
1. The threshold arithmetic for delta <= 1/2 follows from the stated score bound and Hessian lower bound: 2 sqrt(2d/(48d+16)) + 4/(3(48d+16)) <= 1/sqrt(6)+1/12 < 1/2. This does not verify concentration/probability constants.
2. Critical software bug: O=I, counts=(100,100) gives R_max=0, N_eff_graph=2e17, although states are completely disconnected. Extra null directions must be detected before computing resistance; refuse invalid/uncertain graph rank. The solver also returns optimizer parameters without checking convergence.
3. Theorem 3(1): combining the stated two comparison factors sqrt(2) and 2 log 2 gives 4 log 2 multiplying the score bound and sqrt(R_eff), not 2 sqrt(2) log 2 as stated. A tighter argument would need to be supplied to justify the smaller coefficient. Theorem 3(2) proof omits explicit Hessian perturbation and scalar Bernstein bounded-increment terms; allocate failure probabilities for all events and derive remainder.
4. Theorem 4B is only a short sketch without complete joint probability laws or divergence derivation, including constraints on perturbations across edges; not an established multistate minimax theorem. Scope of 4A coordinate observations requires independent proof beyond density-evaluation-only oracle.
5. Theorem 5 has no full proof in the LaTeX manuscript. Theorem 6a is conditional on population assumptions; no fully observable acceptance guarantee demonstrated. Theorem 8 fallback event as written depends on f_star through delta; use a data-measurable existence/convergence event and account for failure on its complement. Theorem 7 is a weight perturbation result, not full PMF uncertainty certification.
6. Theorem 9A proof appears promising; 9B requires positive beta at an attained variance minimizer, and proof should explicitly include boundary issues. Benchmark optimization rounds use newly sampled data; observed resistance changes are not controlled evidence of lower population variance or cost.
7. Actual bibliography title of arXiv:2610.17403 is Overlap, Not Moments: Finite-Sample Theory for Bridge Sampling (not the manuscript's subtitle). Novelty claims require further verification.

This is a preliminary audit, not a final theorem-by-theorem validation. Do not submit the manuscript yet.
