/-
  MBAROverlapLaplacian.lean
  Formal Verification Core for:
  "Overlap Laplacians and Effective Resistance: Non-Asymptotic Finite-Sample Theory
   and Minimax Optimality for Multistate Bennett Acceptance Ratio (MBAR)"

  Author: Tommaso R. Marena
  Target: Lean 4 / Mathlib (purely algebraic & real-analytic core; 0 measure theory)

  Contents:
  1. Proposition 1: Exact pymbar Overlap-Laplacian Identity  L_hat(f_hat) = S (I - O)
  2. Theorem 1: Sharp Shift-Invariant Pseudo-Self-Concordance |D^3 ell[h,h,h]| <= osc(h) * D^2 ell[h,h]
  3. Lemma (Popoviciu): Var_pi(v) <= (1/4) * osc(v)^2
  4. Theorem 2: Deterministic Resistance-Diameter Localization (Grönwall + sharp -log(1-delta)/delta)
-/

import Mathlib.Data.Real.Basic
import Mathlib.Data.Finset.Basic
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecialFunctions.ExpDeriv
import Mathlib.Tactic

open BigOperators Finset

namespace MBAROverlapLaplacian

variable {K N : ℕ}

/-- Probability simplex predicate on `Fin K`. -/
def IsProbVec (π : Fin K → ℝ) : Prop :=
  (∀ k, 0 ≤ π k) ∧ (∑ k, π k = 1)

/-- Empirical mean of `h : Fin K → ℝ` under probability vector `π`. -/
def pMean (π h : Fin K → ℝ) : ℝ :=
  ∑ k, π k * h k

/-- Empirical variance (2nd central moment = Hessian quadratic form h^T (diag(π) - π π^T) h). -/
def pVar (π h : Fin K → ℝ) : ℝ :=
  ∑ k, π k * (h k - pMean π h) ^ 2

/-- Empirical 3rd central moment (= D^3 log-sum-exp [h, h, h]). -/
def pThird (π h : Fin K → ℝ) : ℝ :=
  ∑ k, π k * (h k - pMean π h) ^ 3

/-- Shift-invariant oscillation seminorm `osc(h) = max h - min h` (for nonempty `Fin K`). -/
noncomputable def osc [NeZero K] (h : Fin K → ℝ) : ℝ :=
  (Finset.univ.sup' Finset.univ_nonempty h) - (Finset.univ.inf' Finset.univ_nonempty h)

/-- Helper: every entry `h k` lies between `inf' h` and `sup' h`. -/
lemma inf_le_apply_le_sup [NeZero K] (h : Fin K → ℝ) (k : Fin K) :
    Finset.univ.inf' Finset.univ_nonempty h ≤ h k ∧
    h k ≤ Finset.univ.sup' Finset.univ_nonempty h := by
  constructor
  · exact Finset.inf'_le h (Finset.mem_univ k)
  · exact Finset.le_sup' h (Finset.mem_univ k)

/-- Helper: the mean `pMean π h` lies between `inf' h` and `sup' h`. -/
lemma inf_le_pMean_le_sup [NeZero K] {π : Fin K → ℝ} (hπ : IsProbVec π) (h : Fin K → ℝ) :
    Finset.univ.inf' Finset.univ_nonempty h ≤ pMean π h ∧
    pMean π h ≤ Finset.univ.sup' Finset.univ_nonempty h := by
  set m := Finset.univ.inf' Finset.univ_nonempty h
  set M := Finset.univ.sup' Finset.univ_nonempty h
  constructor
  · calc
      m = ∑ k, π k * m := by rw [← Finset.sum_mul, hπ.2, one_mul]
      _ ≤ ∑ k, π k * h k := by
        apply Finset.sum_le_sum
        intro k _
        exact mul_le_mul_of_nonneg_left (inf_le_apply_le_sup h k).1 (hπ.1 k)
  · calc
      ∑ k, π k * h k ≤ ∑ k, π k * M := by
        apply Finset.sum_le_sum
        intro k _
        exact mul_le_mul_of_nonneg_left (inf_le_apply_le_sup h k).2 (hπ.1 k)
      _ = M := by rw [← Finset.sum_mul, hπ.2, one_mul]

/-- Helper: pointwise deviation `|h k - pMean π h| ≤ osc h`. -/
lemma abs_sub_pMean_le_osc [NeZero K] {π : Fin K → ℝ} (hπ : IsProbVec π) (h : Fin K → ℝ) (k : Fin K) :
    |h k - pMean π h| ≤ osc h := by
  have hk := inf_le_apply_le_sup h k
  have hμ := inf_le_pMean_le_sup hπ h
  rw [abs_le, osc]
  constructor <;> linarith

/--
  THEOREM 1 (Pointwise Core): Sharp Shift-Invariant Pseudo-Self-Concordance.
  For every probability vector `π` on `Fin K` and direction `h : Fin K → ℝ`,
    `|pThird π h| ≤ osc h * pVar π h`.
  Averaging over `n : Fin N` immediately yields `|D^3 ℓ_N(f)[h,h,h]| ≤ osc(h) * h^T ∇²ℓ_N(f) h`.
-/
theorem mbar_third_deriv_le_osc_hessian [NeZero K]
    {π : Fin K → ℝ} (hπ : IsProbVec π) (h : Fin K → ℝ) :
    |pThird π h| ≤ osc h * pVar π h := by
  unfold pThird pVar
  calc
    |∑ k, π k * (h k - pMean π h) ^ 3|
      ≤ ∑ k, |π k * (h k - pMean π h) ^ 3| := Finset.abs_sum_le_sum_abs _ _
    _ = ∑ k, π k * |h k - pMean π h| * (h k - pMean π h) ^ 2 := by
        apply Finset.sum_congr rfl
        intro k _
        rw [abs_mul, abs_of_nonneg (hπ.1 k)]
        have h3 : |(h k - pMean π h) ^ 3| = |h k - pMean π h| * (h k - pMean π h) ^ 2 := by
          rw [pow_succ, abs_mul, abs_sq, mul_comm]
        rw [h3, mul_assoc]
    _ ≤ ∑ k, π k * osc h * (h k - pMean π h) ^ 2 := by
        apply Finset.sum_le_sum
        intro k _
        have hdev := abs_sub_pMean_le_osc hπ h k
        have hsq : 0 ≤ (h k - pMean π h) ^ 2 := sq_nonneg _
        have hπk : 0 ≤ π k := hπ.1 k
        nlinarith
    _ = osc h * ∑ k, π k * (h k - pMean π h) ^ 2 := by
        rw [Finset.mul_sum]
        apply Finset.sum_congr rfl
        intro k _
        ring

/--
  PROPOSITION 1: Exact pymbar Overlap-Laplacian Identity.
  At MBAR stationarity `(1/N) ∑_n π_{n,i} = s_i`, the empirical Hessian
    `L_hat_{ij} = δ_{ij} (1/N) ∑_n π_{n,i} - (1/N) ∑_n π_{n,i} π_{n,j}`
  equals `S (I - O)` where `O_{ij} = (1 / (N s_i)) ∑_n π_{n,i} π_{n,j}` is the pymbar overlap matrix.
-/
theorem mbar_hessian_eq_overlap_laplacian
    (N_real : ℝ) (hN : N_real ≠ 0)
    (s : Fin K → ℝ) (hs : ∀ i, s i ≠ 0)
    (π : Fin N → Fin K → ℝ)
    (hstat : ∀ i, (∑ n, π n i) / N_real = s i)
    (i j : Fin K) :
    ((if i = j then (∑ n, π n i) / N_real else 0) - (∑ n, π n i * π n j) / N_real)
      = s i * ((if i = j then (1 : ℝ) else 0) - (∑ n, π n i * π n j) / (N_real * s i)) := by
  by_cases hij : i = j
  · subst hij
    simp only [↓reduceIte]
    rw [hstat i]
    have hsi := hs i
    field_simp
  · simp only [hij, ↓reduceIte]
    have hsi := hs i
    field_simp

/--
  POPOVICIU LEMMA (Step 3A Deterministic Bound):
  For any probability vector `π` and direction `v : Fin K → ℝ`,
    `pVar π v ≤ (1 / 4) * (osc v) ^ 2`.
  Combined with `osc(v)^2 ≤ R_max(L) * (v^T L v)`, this gives the deterministic
  Matrix-Chernoff upper bound `0 ≼ (1/N) L^{+/2} A_n L^{+/2} ≼ (R_max(L)/(4N)) P_{1^⊥}`.
-/
theorem popoviciu_pVar_le_quarter_osc_sq [NeZero K]
    {π : Fin K → ℝ} (hπ : IsProbVec π) (v : Fin K → ℝ) :
    pVar π v ≤ (1 / 4 : ℝ) * (osc v) ^ 2 := by
  set m := Finset.univ.inf' Finset.univ_nonempty v
  set M := Finset.univ.sup' Finset.univ_nonempty v
  set mid := (m + M) / 2
  have hmin : pVar π v ≤ ∑ k, π k * (v k - mid) ^ 2 := by
    unfold pVar
    have hdiff :
        (∑ k, π k * (v k - mid) ^ 2) - (∑ k, π k * (v k - pMean π v) ^ 2)
          = (pMean π v - mid) ^ 2 := by
      have hexp : ∀ k, π k * (v k - mid) ^ 2 - π k * (v k - pMean π v) ^ 2
          = 2 * (pMean π v - mid) * (π k * (v k - pMean π v))
            + π k * (pMean π v - mid) ^ 2 := by
        intro k; ring
      rw [← Finset.sum_sub_distrib]
      trans (∑ k, (2 * (pMean π v - mid) * (π k * (v k - pMean π v))
          + π k * (pMean π v - mid) ^ 2))
      · exact Finset.sum_congr rfl (fun k _ => hexp k)
      · rw [Finset.sum_add_distrib, ← Finset.mul_sum, ← Finset.sum_mul, hπ.2, one_mul]
        have hzero : ∑ k, π k * (v k - pMean π v) = 0 := by
          have : ∑ k, π k * (v k - pMean π v) = pMean π v - (∑ k, π k) * pMean π v := by
            unfold pMean
            rw [Finset.sum_mul, ← Finset.sum_sub_distrib]
            exact Finset.sum_congr rfl (fun k _ => by ring)
          rw [this, hπ.2, one_mul, sub_self]
        rw [hzero, mul_zero, zero_add]
    nlinarith [sq_nonneg (pMean π v - mid)]
  calc
    pVar π v ≤ ∑ k, π k * (v k - mid) ^ 2 := hmin
    _ ≤ ∑ k, π k * ((M - m) / 2) ^ 2 := by
        apply Finset.sum_le_sum
        intro k _
        have hk := inf_le_apply_le_sup v k
        have hsq : (v k - mid) ^ 2 ≤ ((M - m) / 2) ^ 2 := by
          have h1 : -((M - m) / 2) ≤ v k - mid := by linarith
          have h2 : v k - mid ≤ (M - m) / 2 := by linarith
          nlinarith
        exact mul_le_mul_of_nonneg_left hsq (hπ.1 k)
    _ = (1 / 4 : ℝ) * (osc v) ^ 2 := by
        rw [← Finset.sum_mul, hπ.2, one_mul, osc]
        ring

/--
  THEOREM 2 (Algebraic Localization Core):
  Given `osc_h ≥ 0`, `h_norm > 0`, `grad_norm ≥ 0`, `sqrt_Rmax > 0`, and `δ = sqrt_Rmax * grad_norm < 1`,
  if the Grönwall-integrated convexity inequality
    `h_norm * ((1 - exp(-osc_h)) / osc_h) ≤ grad_norm`
  and the resistance-diameter bound
    `osc_h ≤ sqrt_Rmax * h_norm`
  hold, then:
    (a) `osc_h ≤ -log(1 - δ)`
    (b) `h_norm ≤ (-log(1 - δ) / δ) * grad_norm` (for `δ > 0`).
-/
theorem mbar_resistance_localization_core
    {osc_h h_norm grad_norm sqrt_Rmax : ℝ}
    (hosc_pos : 0 < osc_h)
    (hh_pos : 0 < h_norm)
    (hR_pos : 0 < sqrt_Rmax)
    (hδ_pos : 0 < sqrt_Rmax * grad_norm)
    (hδ_lt : sqrt_Rmax * grad_norm < 1)
    (hgronwall : h_norm * ((1 - Real.exp (-osc_h)) / osc_h) ≤ grad_norm)
    (hres : osc_h ≤ sqrt_Rmax * h_norm) :
    osc_h ≤ -Real.log (1 - sqrt_Rmax * grad_norm) ∧
    h_norm ≤ (-Real.log (1 - sqrt_Rmax * grad_norm) / (sqrt_Rmax * grad_norm)) * grad_norm := by
  set δ := sqrt_Rmax * grad_norm
  have h1mδ_pos : 0 < 1 - δ := by linarith
  have hexp_pos : 0 < 1 - Real.exp (-osc_h) := by
    have : Real.exp (-osc_h) < 1 := by
      rw [Real.exp_lt_one_iff]
      linarith
    linarith
  -- Step 1: 1 - exp(-osc_h) ≤ δ
  have hstep1 : 1 - Real.exp (-osc_h) ≤ δ := by
    have hmul : sqrt_Rmax * (h_norm * ((1 - Real.exp (-osc_h)) / osc_h)) ≤ δ :=
      mul_le_mul_of_nonneg_left hgronwall hR_pos.le
    have hfrac : 0 < (1 - Real.exp (-osc_h)) / osc_h := div_pos hexp_pos hosc_pos
    have hlow : 1 - Real.exp (-osc_h) ≤ (sqrt_Rmax * h_norm) * ((1 - Real.exp (-osc_h)) / osc_h) := by
      calc
        1 - Real.exp (-osc_h) = osc_h * ((1 - Real.exp (-osc_h)) / osc_h) := by
          field_simp
        _ ≤ (sqrt_Rmax * h_norm) * ((1 - Real.exp (-osc_h)) / osc_h) :=
          mul_le_mul_of_nonneg_right hres hfrac.le
    linarith
  -- Step 2: osc_h ≤ -log(1 - δ)
  have hosc_bound : osc_h ≤ -Real.log (1 - δ) := by
    have h2 : 1 - δ ≤ Real.exp (-osc_h) := by linarith
    have hlog := Real.log_le_log h1mδ_pos h2
    rw [Real.log_exp] at hlog
    linarith
  -- Step 3: h_norm ≤ (-log(1 - δ) / δ) * grad_norm
  -- Using monotonicity of u ↦ (1 - exp(-u)) / u on (0, ∞):
  -- Since 0 < osc_h ≤ -log(1 - δ), we have (1 - exp(-osc_h))/osc_h ≥ δ / (-log(1 - δ)).
  constructor
  · exact hosc_bound
  · -- Equivalently, show h_norm * δ ≤ -log(1 - δ) * grad_norm
    -- Wait: from hres and hosc_bound we actually get an even simpler check if needed,
    -- and via monotonicity of (1 - e^{-u})/u:
    have hlog_pos : 0 < -Real.log (1 - δ) := by
      have : Real.log (1 - δ) < 0 := Real.log_neg h1mδ_pos (by linarith)
      linarith
    -- Key elementary inequality: for 0 < a ≤ b, (1 - e^{-b}) / b ≤ (1 - e^{-a}) / a
    -- i.e. a * (1 - e^{-b}) ≤ b * (1 - e^{-a})
    have hmono : δ / (-Real.log (1 - δ)) ≤ (1 - Real.exp (-osc_h)) / osc_h := by
      rw [div_le_div_iff₀ hlog_pos hosc_pos]
      have hsub : δ = 1 - Real.exp (-(-Real.log (1 - δ))) := by
        rw [neg_neg, Real.exp_log h1mδ_pos]
        ring
      -- For 0 < a ≤ b, f(u) = (1 - e^{-u})/u is decreasing because e^u ≥ 1 + u + u^2/2...
      -- Specifically, g(t) = a*(1 - e^{-t}) - t*(1 - e^{-a}) has g(a)=0 and g'(t) = a*e^{-t} - (1 - e^{-a}) ≤ 0 for t ≥ a.
      -- Direct 1-line check using exp(-x) ≥ 1 - x:
      -- Let t = b - a ≥ 0; we need a*(1 - e^{-b}) ≤ b*(1 - e^{-a}).
      set a := osc_h
      set b := -Real.log (1 - δ)
      have hab : a ≤ b := hosc_bound
      have he1 : Real.exp (b - a) ≥ 1 + (b - a) := by
        linarith [Real.add_one_le_exp (b - a)]
      have he2 : Real.exp a ≥ 1 + a := by
        linarith [Real.add_one_le_exp a]
      -- Multiply a*(1 - e^{-b}) ≤ b*(1 - e^{-a}) by e^b > 0:
      -- Equivalent to a*(e^b - 1) ≤ b*(e^b - e^{b-a}), i.e. b*e^{b-a} - a ≤ (b - a)*e^b.
      have heb_pos : 0 < Real.exp b := Real.exp_pos b
      have hkey : a * (1 - Real.exp (-b)) ≤ b * (1 - Real.exp (-a)) := by
        have hba : 0 ≤ b - a := by linarith
        -- Since e^a ≥ 1 + a and e^{b-a} ≥ 1 + (b - a), we check:
        -- (b - a) * e^b - b * e^{b-a} + a = e^{b-a} * ((b - a) * e^a - b) + a
        -- Wait: (b - a)*e^a - b ≥ (b-a)*(1+a) - b = a*(b - a - 1), not always ≥ 0!
        -- Instead use e^{-b} = e^{-a} * e^{-(b-a)} ≥ e^{-a} * (1 - (b-a))? No, reverse sign:
        -- 1 - e^{-t} ≤ t, so e^{-a} - e^{-b} = e^{-a}(1 - e^{-(b-a)}) ≤ e^{-a}(b - a).
        -- Also a * e^{-a} ≤ 1 - e^{-a} (since e^a ≥ 1 + a)!
        -- Therefore: a*(1 - e^{-b}) - a*(1 - e^{-a}) = a*(e^{-a} - e^{-b}) ≤ a*e^{-a}*(b - a) ≤ (1 - e^{-a})*(b - a)!!
        -- Rearranging: a*(1 - e^{-b}) ≤ b*(1 - e^{-a})! ONE LINE!!
        have h_ea : a * Real.exp (-a) ≤ 1 - Real.exp (-a) := by
          have h1 : 1 + a ≤ Real.exp a := by linarith [Real.add_one_le_exp a]
          have h2 : (1 + a) * Real.exp (-a) ≤ Real.exp a * Real.exp (-a) :=
            mul_le_mul_of_nonneg_right h1 (Real.exp_pos (-a)).le
          rw [← Real.exp_add, add_neg_cancel, Real.exp_zero] at h2
          linarith
        have h_diff : Real.exp (-a) - Real.exp (-b) ≤ Real.exp (-a) * (b - a) := by
          have h1 : 1 - (b - a) ≤ Real.exp (-(b - a)) := by
            linarith [Real.add_one_le_exp (-(b - a))]
          have h2 : Real.exp (-a) * (1 - (b - a)) ≤ Real.exp (-a) * Real.exp (-(b - a)) :=
            mul_le_mul_of_nonneg_left h1 (Real.exp_pos (-a)).le
          rw [← Real.exp_add] at h2
          have hidx : -a + -(b - a) = -b := by ring
          rw [hidx] at h2
          linarith
        have h3 : a * (Real.exp (-a) - Real.exp (-b)) ≤ (a * Real.exp (-a)) * (b - a) := by
          calc
            a * (Real.exp (-a) - Real.exp (-b))
              ≤ a * (Real.exp (-a) * (b - a)) := mul_le_mul_of_nonneg_left h_diff hosc_pos.le
            _ = (a * Real.exp (-a)) * (b - a) := by ring
        have h4 : (a * Real.exp (-a)) * (b - a) ≤ (1 - Real.exp (-a)) * (b - a) :=
          mul_le_mul_of_nonneg_right h_ea hba
        linarith
      rw [hsub]
      exact hkey
    have hstep3 : h_norm * (δ / (-Real.log (1 - δ))) ≤ grad_norm :=
      le_trans (mul_le_mul_of_nonneg_left hmono hh_pos.le) hgronwall
    have hdiv : h_norm ≤ grad_norm / (δ / (-Real.log (1 - δ))) := by
      rwa [le_div_iff₀ (div_pos hδ_pos hlog_pos)]
    calc
      h_norm ≤ grad_norm / (δ / (-Real.log (1 - δ))) := hdiv
      _ = (-Real.log (1 - δ) / δ) * grad_norm := by field_simp

/--
  THEOREM 6b (Deterministic Global Converse Certificate / No-False-Confidence Bound):
  For any cut `A : Finset (Fin K)` and any dataset with softmax responsibilities `π n`
  and generating state labels `lbl n : Fin K`,
    `∑ n, πA n * (1 - πA n) ≤ ∑ n, -Real.log (π n (lbl n))`,
  where `πA n = ∑ k ∈ A, π n k`. Combined with `N / R_hat_max ≤ ∑ n, πA n * (1 - πA n)`
  and global MBAR optimality `CE_N(f_hat) ≤ CE_N(f*)`, this proves a poorly overlapping
  K-state simulation cannot spuriously pass a large `N_eff^graph` certificate.
-/
theorem mbar_converse_certificate_le_cross_entropy
    (π : Fin N → Fin K → ℝ)
    (hprob : ∀ n, IsProbVec (π n))
    (hpos : ∀ n k, 0 < π n k)
    (lbl : Fin N → Fin K)
    (A : Finset (Fin K)) :
    (∑ n : Fin N, (∑ k ∈ A, π n k) * (1 - ∑ k ∈ A, π n k))
      ≤ ∑ n : Fin N, -Real.log (π n (lbl n)) := by
  apply Finset.sum_le_sum
  intro n _
  set pA := ∑ k ∈ A, π n k
  have hpA_nonneg : 0 ≤ pA :=
    Finset.sum_nonneg (fun k _ => (hprob n).1 k)
  have hpA_le_one : pA ≤ 1 := by
    calc
      pA = ∑ k ∈ A, π n k := rfl
      _ ≤ ∑ k ∈ Finset.univ, π n k :=
        Finset.sum_le_univ_sum_of_nonneg (hprob n).1
      _ = 1 := (hprob n).2
  have hlog : 1 - π n (lbl n) ≤ -Real.log (π n (lbl n)) := by
    have h1 := Real.log_le_sub_one_of_pos (hpos n (lbl n))
    linarith
  by_cases hmem : lbl n ∈ A
  · have hle : π n (lbl n) ≤ pA :=
      Finset.single_le_sum (fun k _ => (hprob n).1 k) hmem
    have hprod : pA * (1 - pA) ≤ 1 - pA := by nlinarith
    linarith
  · have hsum_le : pA + π n (lbl n) ≤ 1 := by
      have hdisj : lbl n ∉ A := hmem
      have hinsert : ∑ k ∈ insert (lbl n) A, π n k = π n (lbl n) + pA :=
        Finset.sum_insert hdisj
      have huniv : ∑ k ∈ insert (lbl n) A, π n k ≤ ∑ k ∈ Finset.univ, π n k :=
        Finset.sum_le_univ_sum_of_nonneg (hprob n).1
      rw [hinsert, (hprob n).2] at huniv
      linarith
    have hprod : pA * (1 - pA) ≤ pA := by nlinarith
    linarith

/--
  THEOREM 7 (Softmax Reweighting Ratio Stability for MBAR Observables & PMFs):
  For any probability vector `π` on `Fin K`, shift vector `h : Fin K → ℝ`, and state `k`,
    `exp(-osc h) ≤ (∑ j, π j * exp(h j - h k))⁻¹ ≤ exp(osc h)`.
  Substituting `h = f_hat - f*` with `osc h ≤ -log(1 - δ_N)` (Theorem 2) yields
  `1 - δ_N ≤ W_{n,k}(f_hat) / W_{n,k}(f*) ≤ 1 / (1 - δ_N)` for every draw `n`.
-/
theorem mbar_reweighting_ratio_stability [NeZero K]
    {π : Fin K → ℝ} (hπ : IsProbVec π) (h : Fin K → ℝ) (k : Fin K) :
    Real.exp (-osc h) ≤ (∑ j, π j * Real.exp (h j - h k))⁻¹ ∧
    (∑ j, π j * Real.exp (h j - h k))⁻¹ ≤ Real.exp (osc h) := by
  set S := ∑ j, π j * Real.exp (h j - h k)
  have hlow : Real.exp (-osc h) ≤ S := by
    calc
      Real.exp (-osc h) = ∑ j, π j * Real.exp (-osc h) := by
        rw [← Finset.sum_mul, hπ.2, one_mul]
      _ ≤ ∑ j, π j * Real.exp (h j - h k) := by
        apply Finset.sum_le_sum
        intro j _
        have hj := inf_le_apply_le_sup h j
        have hk := inf_le_apply_le_sup h k
        have hdiff : -osc h ≤ h j - h k := by unfold osc; linarith
        exact mul_le_mul_of_nonneg_left (Real.exp_le_exp.mpr hdiff) (hπ.1 j)
  have hhigh : S ≤ Real.exp (osc h) := by
    calc
      ∑ j, π j * Real.exp (h j - h k) ≤ ∑ j, π j * Real.exp (osc h) := by
        apply Finset.sum_le_sum
        intro j _
        have hj := inf_le_apply_le_sup h j
        have hk := inf_le_apply_le_sup h k
        have hdiff : h j - h k ≤ osc h := by unfold osc; linarith
        exact mul_le_mul_of_nonneg_left (Real.exp_le_exp.mpr hdiff) (hπ.1 j)
      _ = Real.exp (osc h) := by rw [← Finset.sum_mul, hπ.2, one_mul]
  have hS_pos : 0 < S := lt_of_lt_of_le (Real.exp_pos (-osc h)) hlow
  constructor
  · rw [← Real.exp_neg (osc h)]
    have : Real.exp (osc h)⁻¹ ≤ S⁻¹ := inv_le_inv₀ (Real.exp_pos (osc h)) hS_pos |>.mpr hhigh
    rwa [← Real.exp_neg] at this
  · have : S⁻¹ ≤ (Real.exp (-osc h))⁻¹ := inv_le_inv₀ hS_pos (Real.exp_pos (-osc h)) |>.mpr hlow
    rwa [← Real.exp_neg, neg_neg] at this

/--
  THEOREM 4A (Algebraic Core of Le Cam Two-Sample Minimax Lower Bound):
  For any `0 < ε ≤ 1/2` and `0 ≤ Δ`, the single-sample χ² divergence between
  `Bern(ε exp(-Δ))` and `Bern(ε)` satisfies
    `ε * (1 - exp(-Δ))^2 / (1 - ε) ≤ 2 * ε * Δ^2`.
-/
theorem le_cam_bernoulli_chi2_bound
    {ε Δ : ℝ} (hε_pos : 0 < ε) (hε_half : ε ≤ 1 / 2) (hΔ_nonneg : 0 ≤ Δ) :
    ε * (1 - Real.exp (-Δ)) ^ 2 / (1 - ε) ≤ 2 * ε * Δ ^ 2 := by
  have h1mε_ge : (1 / 2 : ℝ) ≤ 1 - ε := by linarith
  have h1mε_pos : 0 < 1 - ε := by linarith
  have hstep1 : 0 ≤ 1 - Real.exp (-Δ) := by
    have : Real.exp (-Δ) ≤ 1 := Real.exp_le_one_iff.mpr (by linarith)
    linarith
  have hstep2 : 1 - Real.exp (-Δ) ≤ Δ := by
    have := Real.add_one_le_exp (-Δ)
    linarith
  have hsq : (1 - Real.exp (-Δ)) ^ 2 ≤ Δ ^ 2 := by nlinarith
  rw [div_le_iff₀ h1mε_pos]
  nlinarith

/--
  THEOREM 9 (Perspective Convexity Identity):
  Exact algebraic identity showing that `(a, b) ↦ a^2 / b` is jointly convex on `ℝ × (0, ∞)`.
-/
theorem mbar_perspective_convex_identity
    {a a' b b' θ : ℝ}
    (hb : 0 < b) (hb' : 0 < b') (hθ0 : 0 ≤ θ) (hθ1 : θ ≤ 1) :
    (θ * a + (1 - θ) * a') ^ 2 / (θ * b + (1 - θ) * b')
      ≤ θ * (a ^ 2 / b) + (1 - θ) * (a' ^ 2 / b') := by
  have hden : 0 < θ * b + (1 - θ) * b' := by nlinarith
  have hident :
      θ * (a ^ 2 / b) + (1 - θ) * (a' ^ 2 / b')
        - (θ * a + (1 - θ) * a') ^ 2 / (θ * b + (1 - θ) * b')
        = θ * (1 - θ) * (a * b' - a' * b) ^ 2 / (b * b' * (θ * b + (1 - θ) * b')) := by
    field_simp
    ring
  have hrhs_nonneg :
      0 ≤ θ * (1 - θ) * (a * b' - a' * b) ^ 2 / (b * b' * (θ * b + (1 - θ) * b')) := by
    have h1mθ : 0 ≤ 1 - θ := by linarith
    positivity
  linarith

/--
  THEOREM 9 (Pointwise Loewner Concavity of the Overlap Graph Laplacian L(s)):
  For any configuration densities `p : Fin K → ℝ`, potential vector `v : Fin K → ℝ`,
  and sample allocations `s, s' : Fin K → ℝ` with positive mixture densities,
  the quadratic form integrand `w ↦ ∑ k, w k * p k * v k^2 - (∑ k, w k * p k * v k)^2 / (∑ k, w k * p k)`
  is concave in `w`, proving Loewner concavity of `s ↦ L(s)` and global convexity of
  `s ↦ R_eff(L(s); i, j)` and `s ↦ R_max(L(s))` on the simplex.
-/
theorem mbar_laplacian_quad_concave_in_s
    (p v s s' : Fin K → ℝ) {θ : ℝ}
    (hb : 0 < ∑ k, s k * p k)
    (hb' : 0 < ∑ k, s' k * p k)
    (hθ0 : 0 ≤ θ) (hθ1 : θ ≤ 1) :
    θ * ((∑ k, s k * p k * v k ^ 2) - (∑ k, s k * p k * v k) ^ 2 / (∑ k, s k * p k))
      + (1 - θ) * ((∑ k, s' k * p k * v k ^ 2) - (∑ k, s' k * p k * v k) ^ 2 / (∑ k, s' k * p k))
      ≤ (∑ k, (θ * s k + (1 - θ) * s' k) * p k * v k ^ 2)
        - (∑ k, (θ * s k + (1 - θ) * s' k) * p k * v k) ^ 2
          / (∑ k, (θ * s k + (1 - θ) * s' k) * p k) := by
  have hlin2 :
      ∑ k, (θ * s k + (1 - θ) * s' k) * p k * v k ^ 2
        = θ * (∑ k, s k * p k * v k ^ 2) + (1 - θ) * (∑ k, s' k * p k * v k ^ 2) := by
    rw [Finset.mul_sum, Finset.mul_sum, ← Finset.sum_add_distrib]
    exact Finset.sum_congr rfl (fun k _ => by ring)
  have hlin1 :
      ∑ k, (θ * s k + (1 - θ) * s' k) * p k * v k
        = θ * (∑ k, s k * p k * v k) + (1 - θ) * (∑ k, s' k * p k * v k) := by
    rw [Finset.mul_sum, Finset.mul_sum, ← Finset.sum_add_distrib]
    exact Finset.sum_congr rfl (fun k _ => by ring)
  have hlin0 :
      ∑ k, (θ * s k + (1 - θ) * s' k) * p k
        = θ * (∑ k, s k * p k) + (1 - θ) * (∑ k, s' k * p k) := by
    rw [Finset.mul_sum, Finset.mul_sum, ← Finset.sum_add_distrib]
    exact Finset.sum_congr rfl (fun k _ => by ring)
  rw [hlin2, hlin1, hlin0]
  have hconv := mbar_perspective_convex_identity
    (a := ∑ k, s k * p k * v k) (a' := ∑ k, s' k * p k * v k) hb hb' hθ0 hθ1
  linarith

/--
  THEOREM 1 (Mixed-Direction Loewner Core):
  For any probability vector `π` on `Fin K` and ANY two directions `u, h : Fin K → ℝ`,
    `|∑ k, π k * (h k - pMean π h) * (u k - pMean π u)^2| ≤ osc h * pVar π u`.
  Integrating via Grönwall's inequality for every `u ∈ ℝ^K` yields the full Loewner-order
  Hessian comparison `exp(-t * osc h) * ∇²ℓ(f) ≼ ∇²ℓ(f + t h) ≼ exp(t * osc h) * ∇²ℓ(f)`
  used in Theorems 3' and 6a.
-/
theorem mbar_mixed_third_deriv_le_osc_hessian [NeZero K]
    {π : Fin K → ℝ} (hπ : IsProbVec π) (u h : Fin K → ℝ) :
    |∑ k, π k * (h k - pMean π h) * (u k - pMean π u) ^ 2| ≤ osc h * pVar π u := by
  unfold pVar
  calc
    |∑ k, π k * (h k - pMean π h) * (u k - pMean π u) ^ 2|
      ≤ ∑ k, |π k * (h k - pMean π h) * (u k - pMean π u) ^ 2| :=
        Finset.abs_sum_le_sum_abs _ _
    _ = ∑ k, π k * |h k - pMean π h| * (u k - pMean π u) ^ 2 := by
        apply Finset.sum_congr rfl
        intro k _
        rw [abs_mul, abs_mul, abs_of_nonneg (hπ.1 k), abs_of_nonneg (sq_nonneg _)]
    _ ≤ ∑ k, π k * osc h * (u k - pMean π u) ^ 2 := by
        apply Finset.sum_le_sum
        intro k _
        have hdev := abs_sub_pMean_le_osc hπ h k
        have hsq : 0 ≤ (u k - pMean π u) ^ 2 := sq_nonneg _
        have hπk : 0 ≤ π k := hπ.1 k
        nlinarith
    _ = osc h * ∑ k, π k * (u k - pMean π u) ^ 2 := by
        rw [Finset.mul_sum]
        apply Finset.sum_congr rfl
        intro k _
        ring

end MBAROverlapLaplacian