# MBAR research handoff — preliminary audit snapshot

This is a consolidation of the five recovered Google Drive text exports, extracted source files, compiled manuscript, actual synthetic benchmark logs, independent preliminary audit, and original research conversation. The Drive originals have not been altered. The supplied Lean source is uncompiled; there is no pinned Lean/Mathlib project or axiom report. No real molecular dataset benchmark was performed. The manuscript is NOT validated or ready for submission. PDF compilation and synthetic tests are not mathematical proof. The six Gemini referee-style reviews are not independent external peer review.

## Start here
1. `preliminary_audit.md` — outstanding mathematical and software defects.
2. `METRICCHAIN_HANDOFF.md` — proposed research mandate.
3. `mbar_overlap_laplacian.tex` and `.pdf` — research manuscript; claims remain provisional.
4. `MBAROverlapLaplacian.lean` and `benchmark_mbar_resistance.py` — source files recovered from Google Docs text exports.
5. `benchmark_execution.log`, `disconnected_counterexample.log`, `latex_execution.log` — actual preliminary execution evidence.
6. The two long-titled text files — Gemini's manuscript and audit report.
7. `original_research_conversation.txt` — original development history before the reported repairs.
8. `MANIFEST.sha256` — integrity checks for this snapshot, not a validity certificate.

## Reproduction
Run `python benchmark_mbar_resistance.py` in a Python environment with NumPy and SciPy. The preliminary run used NumPy 2.3.5 and SciPy 1.17.0, with seed 20261127. Run `pdflatex -interaction=nonstopmode -halt-on-error mbar_overlap_laplacian.tex` twice for the manuscript. Establish a pinned Lean 4/Mathlib project before attempting the Lean build. See the audit for limitations. The archive preserves all source exports and includes auxiliary LaTeX outputs for provenance.
